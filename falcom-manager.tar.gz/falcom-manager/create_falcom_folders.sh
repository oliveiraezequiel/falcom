#!/bin/bash

mkdir -p ~/falcom-manager/icons

# =========================================================
# PASTA FALCOM PRETA E DOURADA
# =========================================================

convert -size 512x512 xc:'#050505' \
-fill '#d4af37' \
-draw 'roundrectangle 30,120 480,430 30,30' \
-fill '#111111' \
-draw 'roundrectangle 55,150 455,400 20,20' \
-fill '#d4af37' \
-draw 'roundrectangle 70,85 240,160 20,20' \
-fill gold \
-font DejaVu-Sans-Bold \
-pointsize 62 \
-gravity center \
-draw "text 0,50 'FALCOM'" \
~/falcom-manager/icons/folder_gold.png

# =========================================================
# PASTA ROOT
# =========================================================

convert -size 512x512 xc:'#050505' \
-fill '#b8860b' \
-draw 'roundrectangle 30,120 480,430 30,30' \
-fill '#1a1a1a' \
-draw 'roundrectangle 55,150 455,400 20,20' \
-fill red \
-font DejaVu-Sans-Bold \
-pointsize 58 \
-gravity center \
-draw "text 0,50 'ROOT'" \
~/falcom-manager/icons/folder_root.png

# =========================================================
# PASTA SSD
# =========================================================

convert -size 512x512 xc:'#050505' \
-fill '#ffd700' \
-draw 'roundrectangle 30,120 480,430 30,30' \
-fill '#0f0f0f' \
-draw 'roundrectangle 55,150 455,400 20,20' \
-fill gold \
-font DejaVu-Sans-Bold \
-pointsize 58 \
-gravity center \
-draw "text 0,50 'SSD'" \
~/falcom-manager/icons/folder_ssd.png

# =========================================================
# PASTA USB
# =========================================================

convert -size 512x512 xc:'#050505' \
-fill '#d4af37' \
-draw 'roundrectangle 30,120 480,430 30,30' \
-fill '#101010' \
-draw 'roundrectangle 55,150 455,400 20,20' \
-fill gold \
-font DejaVu-Sans-Bold \
-pointsize 58 \
-gravity center \
-draw "text 0,50 'USB'" \
~/falcom-manager/icons/folder_usb.png

echo "Pastas FALCOM preto e dourado criadas com sucesso."
