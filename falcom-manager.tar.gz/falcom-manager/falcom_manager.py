#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# =========================================================
# FALCOM FILE MANAGER
# BLACK GOLD EDITION
# Ubuntu 22.04+
# =========================================================

import gi
import os
import sys
import shutil
import mimetypes
import subprocess

from pathlib import Path

gi.require_version("Gtk", "3.0")

from gi.repository import Gtk
from gi.repository import Gdk
from gi.repository import GdkPixbuf

# =========================================================
# INICIAR GTK
# =========================================================

Gtk.init(sys.argv)

# =========================================================
# TEMA ESCURO
# =========================================================

try:

    settings = Gtk.Settings.get_default()

    if settings:

        settings.set_property(
            "gtk-application-prefer-dark-theme",
            True
        )

except Exception as e:

    print("Erro GTK:", e)

# =========================================================
# LIXEIRA
# =========================================================

TRASH_DIR = os.path.expanduser(
    "~/.local/share/Trash/files"
)

os.makedirs(
    TRASH_DIR,
    exist_ok=True
)

# =========================================================
# CLASSE PRINCIPAL
# =========================================================

class FalcomManager(Gtk.Window):

    def __init__(self):

        Gtk.Window.__init__(
            self,
            title="FALCOM FILE MANAGER"
        )

        self.set_default_size(
            1400,
            850
        )

        self.current_path = "/"

        # =================================================
        # CSS
        # =================================================

        try:

            css_provider = Gtk.CssProvider()

            css_provider.load_from_path(
                "themes/falcom.css"
            )

            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )

        except Exception as e:

            print("Erro CSS:", e)

        # =================================================
        # ÍCONE
        # =================================================

        try:

            self.set_icon_from_file(
                "icons/falcom_logo.png"
            )

        except:

            pass

        # =================================================
        # HEADERBAR
        # =================================================

        header = Gtk.HeaderBar()

        header.set_show_close_button(True)

        header.props.title = "FALCOM FILE MANAGER"

        self.set_titlebar(header)

        # =================================================
        # BOX PRINCIPAL
        # =================================================

        main_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=6
        )

        main_box.set_border_width(6)

        self.add(main_box)

        # =================================================
        # TOOLBAR
        # =================================================

        toolbar = Gtk.Box(
            spacing=5
        )

        main_box.pack_start(
            toolbar,
            False,
            False,
            0
        )

        # =================================================
        # CAMINHO
        # =================================================

        self.path_entry = Gtk.Entry()

        self.path_entry.set_text("/")

        toolbar.pack_start(
            self.path_entry,
            True,
            True,
            0
        )

        # =================================================
        # BOTÕES
        # =================================================

        buttons = [

            ("ABRIR", self.open_folder),
            ("SISTEMA", self.open_system),
            ("DISCOS", self.show_disks),
            ("ARMAZENAMENTO", self.show_storage_devices),
            ("LIXEIRA", self.show_trash),
            ("EXCLUIR", self.delete_selected),
            ("RESTAURAR", self.restore_selected),
            ("ESVAZIAR", self.empty_trash),
            ("ROOT", self.run_root)

        ]

        for label, callback in buttons:

            button = Gtk.Button(
                label=label
            )

            button.connect(
                "clicked",
                callback
            )

            toolbar.pack_start(
                button,
                False,
                False,
                0
            )

        # =================================================
        # PESQUISA
        # =================================================

        self.search_entry = Gtk.Entry()

        self.search_entry.set_placeholder_text(
            "Pesquisar arquivos..."
        )

        self.search_entry.connect(
            "changed",
            self.search_files
        )

        toolbar.pack_start(
            self.search_entry,
            True,
            True,
            0
        )

        # =================================================
        # TREEVIEW
        # =================================================

        self.store = Gtk.ListStore(
            GdkPixbuf.Pixbuf,
            str,
            str
        )

        self.tree = Gtk.TreeView(
            model=self.store
        )

        self.tree.set_headers_visible(True)

        # =================================================
        # RENDERERS
        # =================================================

        icon_renderer = Gtk.CellRendererPixbuf()

        text_renderer = Gtk.CellRendererText()

        text_renderer.set_property(
            "foreground",
            "gold"
        )

        # =================================================
        # COLUNAS
        # =================================================

        col_icon = Gtk.TreeViewColumn(
            "",
            icon_renderer,
            pixbuf=0
        )

        col_name = Gtk.TreeViewColumn(
            "FALCOM",
            text_renderer,
            text=1
        )

        col_type = Gtk.TreeViewColumn(
            "TIPO",
            text_renderer,
            text=2
        )

        self.tree.append_column(col_icon)
        self.tree.append_column(col_name)
        self.tree.append_column(col_type)

        self.tree.connect(
            "row-activated",
            self.item_activated
        )

        # =================================================
        # SCROLL
        # =================================================

        scroll = Gtk.ScrolledWindow()

        scroll.add(
            self.tree
        )

        main_box.pack_start(
            scroll,
            True,
            True,
            0
        )

        # =================================================
        # TERMINAL
        # =================================================

        terminal_box = Gtk.Box(
            spacing=5
        )

        main_box.pack_start(
            terminal_box,
            False,
            False,
            0
        )

        self.command_entry = Gtk.Entry()

        self.command_entry.set_placeholder_text(
            "Executar comando Linux..."
        )

        terminal_box.pack_start(
            self.command_entry,
            True,
            True,
            0
        )

        exec_button = Gtk.Button(
            label="EXECUTAR"
        )

        exec_button.connect(
            "clicked",
            self.execute_command
        )

        terminal_box.pack_start(
            exec_button,
            False,
            False,
            0
        )

        # =================================================
        # CARREGAR SISTEMA
        # =================================================

        self.load_files("/")

    # =====================================================
    # ÍCONES
    # =====================================================

    def get_icon(self, folder=True):

        try:

            if folder:

                return GdkPixbuf.Pixbuf.new_from_file_at_size(
                    "icons/folder_gold.png",
                    32,
                    32
                )

            return GdkPixbuf.Pixbuf.new_from_file_at_size(
                "icons/file_gold.png",
                32,
                32
            )

        except:

            return None

    # =====================================================
    # CARREGAR ARQUIVOS
    # =====================================================

    def load_files(self, path):

        self.store.clear()

        try:

            files = sorted(
                os.listdir(path)
            )

            for file in files:

                full = os.path.join(
                    path,
                    file
                )

                if os.path.isdir(full):

                    icon = self.get_icon(True)

                    name = f"FALCOM {file}"

                    ftype = "PASTA"

                else:

                    icon = self.get_icon(False)

                    name = file

                    mime = mimetypes.guess_type(full)[0]

                    if mime:

                        ftype = mime

                    else:

                        ftype = "ARQUIVO"

                self.store.append([
                    icon,
                    name,
                    ftype
                ])

            self.current_path = path

            self.path_entry.set_text(path)

        except Exception as e:

            print("Erro carregar:", e)

    # =====================================================
    # ABRIR CAMINHO
    # =====================================================

    def open_folder(self, widget):

        path = self.path_entry.get_text()

        if os.path.exists(path):

            self.load_files(path)

    # =====================================================
    # ABRIR ITEM
    # =====================================================

    def item_activated(
        self,
        tree,
        path,
        column
    ):

        model = tree.get_model()

        item = model[path][1]

        real_name = item.replace(
            "FALCOM ",
            ""
        )

        full = os.path.join(
            self.current_path,
            real_name
        )

        try:

            if os.path.isdir(full):

                self.load_files(full)

            else:

                if os.access(full, os.X_OK):

                    subprocess.Popen([full])

                else:

                    subprocess.Popen([
                        "xdg-open",
                        full
                    ])

        except Exception as e:

            print("Erro abrir:", e)

    # =====================================================
    # PESQUISA
    # =====================================================

    def search_files(self, widget):

        text = self.search_entry.get_text().lower()

        self.store.clear()

        try:

            for file in sorted(
                os.listdir(self.current_path)
            ):

                if text in file.lower():

                    full = os.path.join(
                        self.current_path,
                        file
                    )

                    if os.path.isdir(full):

                        icon = self.get_icon(True)

                        name = f"FALCOM {file}"

                        ftype = "PASTA"

                    else:

                        icon = self.get_icon(False)

                        name = file

                        ftype = "ARQUIVO"

                    self.store.append([
                        icon,
                        name,
                        ftype
                    ])

        except Exception as e:

            print("Erro pesquisa:", e)

    # =====================================================
    # TERMINAL
    # =====================================================

    def execute_command(self, widget):

        command = self.command_entry.get_text()

        try:

            subprocess.Popen(
                command,
                shell=True
            )

        except Exception as e:

            print("Erro comando:", e)

    # =====================================================
    # SISTEMA
    # =====================================================

    def open_system(self, widget):

        self.load_files("/")

    # =====================================================
    # DISCOS
    # =====================================================

    def show_disks(self, widget):

        self.store.clear()

        try:

            result = subprocess.check_output(
                [
                    "lsblk",
                    "-o",
                    "NAME,SIZE,TYPE,MOUNTPOINT",
                    "-nr"
                ]
            ).decode()

            for line in result.splitlines():

                icon = self.get_icon(True)

                self.store.append([
                    icon,
                    line,
                    "DISCO"
                ])

        except Exception as e:

            print("Erro discos:", e)

    # =====================================================
    # ARMAZENAMENTO
    # =====================================================

    def show_storage_devices(self, widget):

        self.store.clear()

        try:

            result = subprocess.check_output(

                [
                    "lsblk",
                    "-o",
                    "NAME,SIZE,TYPE,MOUNTPOINT,FSTYPE",
                    "-nr"
                ]

            ).decode()

            lines = result.splitlines()

            for line in lines:

                parts = line.split()

                if len(parts) >= 3:

                    name = parts[0]

                    size = parts[1]

                    dtype = parts[2]

                    mountpoint = ""

                    filesystem = ""

                    if len(parts) >= 4:

                        mountpoint = parts[3]

                    if len(parts) >= 5:

                        filesystem = parts[4]

                    device = f"/dev/{name}"

                    info = f"{dtype.upper()} {size}"

                    if mountpoint:

                        info += f" | {mountpoint}"

                    if filesystem:

                        info += f" | {filesystem}"

                    icon = self.get_icon(True)

                    self.store.append([
                        icon,
                        device,
                        info
                    ])

        except Exception as e:

            print("Erro armazenamento:", e)

    # =====================================================
    # LIXEIRA
    # =====================================================

    def show_trash(self, widget):

        self.load_files(TRASH_DIR)

    # =====================================================
    # EXCLUIR
    # =====================================================

    def delete_selected(self, widget):

        selection = self.tree.get_selection()

        model, treeiter = selection.get_selected()

        if treeiter:

            item = model[treeiter][1]

            real_name = item.replace(
                "FALCOM ",
                ""
            )

            src = os.path.join(
                self.current_path,
                real_name
            )

            dst = os.path.join(
                TRASH_DIR,
                real_name
            )

            try:

                shutil.move(
                    src,
                    dst
                )

                self.load_files(
                    self.current_path
                )

            except Exception as e:

                print("Erro excluir:", e)

    # =====================================================
    # RESTAURAR
    # =====================================================

    def restore_selected(self, widget):

        selection = self.tree.get_selection()

        model, treeiter = selection.get_selected()

        if treeiter:

            item = model[treeiter][1]

            real_name = item.replace(
                "FALCOM ",
                ""
            )

            src = os.path.join(
                TRASH_DIR,
                real_name
            )

            dst = os.path.join(
                str(Path.home()),
                real_name
            )

            try:

                shutil.move(
                    src,
                    dst
                )

                self.load_files(
                    TRASH_DIR
                )

            except Exception as e:

                print("Erro restaurar:", e)

    # =====================================================
    # ESVAZIAR LIXEIRA
    # =====================================================

    def empty_trash(self, widget):

        try:

            for file in os.listdir(TRASH_DIR):

                full = os.path.join(
                    TRASH_DIR,
                    file
                )

                if os.path.isdir(full):

                    shutil.rmtree(full)

                else:

                    os.remove(full)

            self.load_files(TRASH_DIR)

        except Exception as e:

            print("Erro lixeira:", e)

    # =====================================================
    # ROOT
    # =====================================================

    def run_root(self, widget):

        try:

            subprocess.Popen([

                "pkexec",

                "env",

                f"DISPLAY={os.environ.get('DISPLAY')}",

                f"XAUTHORITY={os.environ.get('XAUTHORITY')}",

                "python3",

                os.path.abspath(__file__)

            ])

        except Exception as e:

            print("Erro ROOT:", e)

# =========================================================
# EXECUÇÃO
# =========================================================

try:

    win = FalcomManager()

    win.connect(
        "destroy",
        Gtk.main_quit
    )

    win.show_all()

    Gtk.main()

except Exception as e:

    print("Erro geral:", e)
