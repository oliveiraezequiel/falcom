#!/bin/bash

mkdir -p icons

# =========================================================
# PASTA PRETA E DOURADA
# =========================================================

convert -size 256x256 xc:'#050505' \
-fill '#d4af37' \
-draw 'roundrectangle 15,70 240,220 20,20' \
-fill '#101010' \
-draw 'roundrectangle 30,90 225,205 15,15' \
-fill gold \
-pointsize 34 \
-gravity center \
-draw "text 0,25 'FALCOM'" \
icons/folder_gold.png

# =========================================================
# ARQUIVO
# =========================================================

convert -size 256x256 xc:'#050505' \
-fill '#d4af37' \
-draw 'rectangle 60,20 190,230' \
-fill '#101010' \
-draw 'rectangle 75,40 175,210' \
-fill gold \
-pointsize 28 \
-gravity center \
-draw "text 0,25 'FILE'" \
icons/file_gold.png

# =========================================================
# LOGO
# =========================================================

convert -size 256x256 xc:'#050505' \
-fill gold \
-draw 'circle 128,128 128,30' \
-fill '#050505' \
-draw 'circle 128,128 128,55' \
-fill gold \
-pointsize 72 \
-gravity center \
-draw "text 0,20 'F'" \
icons/falcom_logo.png

chmod -R 755 icons

echo "Ícones FALCOM criados."
