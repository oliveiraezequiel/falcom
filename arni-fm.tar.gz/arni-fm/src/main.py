import gi
import subprocess
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio

class ArniApp(Gtk.Window):
    def __init__(self):
        super().__init__(title="Arni File Manager")
        self.set_default_size(800, 600)
        
        # Layout
        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add(self.box)
        
        # Botão de Mídia
        self.btn = Gtk.Button(label="Abrir Mídia / Escolher App")
        self.btn.connect("clicked", self.abrir_midia)
        self.box.pack_start(self.btn, False, False, 0)

    def abrir_midia(self, widget):
        # Abre o seletor de arquivos do sistema
        dialog = Gtk.FileChooserDialog("Escolha um arquivo", self,
            Gtk.FileChooserAction.OPEN,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK))
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            arquivo = dialog.get_filename()
            # Comando para abrir com aplicativo padrão (ou selector)
            subprocess.Popen(["xdg-open", arquivo])
        dialog.destroy()

win = ArniApp()
win.connect("destroy", Gtk.main_quit)
win.show_all()
Gtk.main()
