#!/usr/bin/env python3
import os
import gi
import subprocess
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk

class ArniFileManager(Gtk.Window):
    def __init__(self, is_root):
        super().__init__(title=f"Arni File Manager {'(ROOT)' if is_root else ''}")
        self.set_default_size(900, 600)
        self.current_path = "/"
        
        # Aplicar Estilo Azul Metálico
        self.apply_styles()
        
        # Layout Principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        self.add(main_box)

        # Barra de Ferramentas: Voltar e Busca
        toolbar = Gtk.Box(spacing=6)
        btn_back = Gtk.Button(label="⬅ Voltar")
        btn_back.connect("clicked", self.go_back)
        self.search_entry = Gtk.Entry()
        self.search_entry.set_placeholder_text("Digite o caminho e dê Enter...")
        self.search_entry.connect("activate", self.on_search)
        
        toolbar.pack_start(btn_back, False, False, 0)
        toolbar.pack_start(self.search_entry, True, True, 0)
        main_box.pack_start(toolbar, False, False, 5)

        # Listagem
        self.model = Gtk.ListStore(str, str)
        self.treeview = Gtk.TreeView(model=self.model)
        self.treeview.append_column(Gtk.TreeViewColumn("Nome", Gtk.CellRendererText(), text=1))
        self.treeview.connect("row-activated", self.on_open)
        # Suporte a navegação por teclado (Cima/Baixo já é nativo do Gtk.TreeView)
        
        scroll = Gtk.ScrolledWindow()
        scroll.add(self.treeview)
        main_box.pack_start(scroll, True, True, 0)

        self.load_dir("/")

    def apply_styles(self):
        css = b"""
        window { background-color: #002b5e; }
        button { background: #4A90E2; color: white; border-radius: 5px; }
        treeview { background-color: #0056b3; color: white; }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def load_dir(self, path):
        try:
            self.model.clear()
            for item in sorted(os.listdir(path)):
                self.model.append(["folder", item])
            self.current_path = path
            self.search_entry.set_text(path)
        except Exception as e:
            print(f"Erro: {e}")

    def go_back(self, widget):
        parent = os.path.dirname(self.current_path)
        self.load_dir(parent)

    def on_search(self, entry):
        path = entry.get_text()
        if os.path.exists(path):
            self.load_dir(path)

    def on_open(self, tv, path, col):
        name = self.model[path][1]
        new_path = os.path.join(self.current_path, name)
        if os.path.isdir(new_path):
            self.load_dir(new_path)
        else:
            subprocess.Popen(["xdg-open", new_path])

if __name__ == "__main__":
    win = ArniFileManager(os.geteuid() == 0)
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
